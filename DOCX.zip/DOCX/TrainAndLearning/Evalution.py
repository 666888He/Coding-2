import numpy as np
from tqdm import tqdm
import random
from Model import FourLayerNeuralNetwork
from Datasets.DataReader import DataReader
from Tools.CalcLoss import CrossEntropy

import cv2


class Evaluter:
    def __init__(self,data_path,batch_size,
                 ch_in,ch_hid,num_cls,model,):

        self.model = FourLayerNeuralNetwork(ch_in,ch_hid,num_cls,None)

        self.model.weight = model.weight

        self.dataloader = DataReader(data_path,batch_size)

        self.loss_fn = CrossEntropy(self.model)

        self.sample_res_num = 5

    def __call__(self):

        par = tqdm(range(self.dataloader.test_num), total=self.dataloader.test_num)
        loss_mean = 0
        total_correct_num = 0
        for batch_id in par:
            sample,target = self.dataloader.get_batch(batch_id)
            pred = self.model.forward(sample)

            loss = self.loss_fn.forward(pred,target)

            pred_label = pred.argmax(axis=1)
            correct_num = len(target[pred_label==target])
            total_correct_num += correct_num
            loss_mean = (loss_mean*batch_id+loss)/(batch_id+1)
            # random choice to draw image and label
            for _ in range(self.sample_res_num):
                draw_id = random.choice(range(self.dataloader.batch_size))
                self.draw_result(sample[draw_id],pred_label[draw_id],target[draw_id])
            par.set_description('Cur Loss: {:5f}, Correct Num: {}'.format(loss_mean,correct_num))

        print("Test end,this model get correct rate:{:5f}".format(total_correct_num/len(self.dataloader.test_label)))

    def draw_result(self,img,pred,target):
        img_size = (-1,int(np.sqrt(len(img))))
        img = np.abs(img-255)
        img = img.reshape(img_size).astype('uint8')
        img_res = cv2.resize(img,(256,256),interpolation=cv2.INTER_LINEAR)
        img_res = np.repeat(np.expand_dims(img_res,axis=2),3,2)
        img_res = cv2.putText(img_res,f'Pred:{pred},Target:{target}',(25,25),cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0,0,255),2)
        cv2.imshow('res',img_res)
        cv2.waitKey(0)