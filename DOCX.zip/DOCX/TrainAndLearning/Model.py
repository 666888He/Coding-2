import numpy as np

class Relu:
    def __init__(self):
        pass

    def forward(self,x):

        return np.maximum(x, 0)

    def backward(self,out_d):

        return 1. * (out_d > 0)


class Softmax():
    def __init__(self):
        self.out = None


    def forward(self, x):
        self.out = np.exp(x) / np.sum(np.exp(x),axis=1,keepdims=True)
        return self.out

    def backward(self, out_d):
        ret = []
        for i in range(out_d.shape[0]):
            softmax_grad = np.diag(self.out[i]) - np.outer(self.out[i], self.out[i])
            ret.append(np.dot(softmax_grad, out_d[i].T))
        ret = np.array(ret)
        return ret

class FourLayerNeuralNetwork(object):
    def __init__(self,ch_in,ch_mid,ch_out,reg_lambda):
        # weight initialization
        self.weight = {}
        self.weight['w1'] = np.random.randn(ch_in, ch_mid) / np.sqrt(ch_in)
        self.weight['b1'] = np.zeros((1, ch_mid))
        self.weight['w2'] = np.random.randn(ch_mid, ch_mid) / np.sqrt(ch_mid)
        self.weight['b2'] = np.zeros((1, ch_mid))
        self.weight['w3'] = np.random.randn(ch_mid, ch_out) / np.sqrt(ch_mid)
        self.weight['b3'] = np.zeros((1, ch_out))        # output size should be corr by classes

        self.relu = Relu()
        self.softmax = Softmax()

        self.reg_lambda = reg_lambda
        self.out = None


    # Neural network forward by forward addition and forward multiplication
    def forward(self,x):
        # input multiply to w1 and add bias b1
        self.z1 = x.dot(self.weight['w1']) + self.weight['b1']
        # self.z1 = (self.z1-np.min(self.z1,axis=1,keepdims=1))/(np.max(self.z1,axis=1,keepdims=1)-np.min(self.z1,axis=1,keepdims=1))
        # using activation to change nonlinear projection
        self.a1 = self.relu.forward(self.z1)

        # repeat ...
        self.z2 = self.a1.dot(self.weight['w2']) + self.weight['b2']
        # self.z2 = (self.z2-np.min(self.z2,axis=1,keepdims=1))/(np.max(self.z2,axis=1,keepdims=1)-np.min(self.z2,axis=1,keepdims=1))

        # using activation to change nonlinear projection
        self.a2 = self.relu.forward(self.z2)

        # repeat ...
        self.z3 = (self.a2.dot(self.weight['w3']) + self.weight['b3']) / x.shape[0]

        # assign probability for every class branch
        self.out = self.softmax.forward(self.z3)

        return self.out

    def backpropagation(self,target,x):
        delta3 = np.copy(self.out)
        bs = x.shape[0]
        delta3[range(bs), target] -= 1  # yhat - y
        dw3 = (self.a2.T).dot(delta3) / bs
        db3 = np.sum(delta3, axis=0, keepdims=True) /bs
        delta2 = delta3.dot(self.weight['w3'].T) * self.relu.backward(self.a2)  # if ReLU
        dw2 = np.dot(self.a1.T, delta2) / bs
        db2 = np.sum(delta2, axis=0) / bs
        # delta2 = delta3.dot(model['W2'].T) * (1 - np.power(a1, 2)) #if tanh
        delta1 = delta2.dot(self.weight['w2'].T) * self.relu.backward(self.a1)  # if ReLU
        dw1 = np.dot(x.T, delta1) / bs
        db1 = np.sum(delta1, axis=0) / bs

        # Add regularization terms
        # dw3 += self.reg_lambda * self.weight['w3']
        # dw2 += self.reg_lambda * self.weight['w2']
        # dw1 += self.reg_lambda * self.weight['w1']

        return dw1,dw2,dw3,db1,db2,db3

    def update(self,grads,learning_rate):
        # weights update with gradients, which generate from prediction and GroundTrue label
        self.weight['w1'] -= learning_rate * grads[0]
        self.weight['w2'] -= learning_rate * grads[1]
        self.weight['w3'] -= learning_rate * grads[2]
        self.weight['b1'] -= learning_rate * grads[3]
        self.weight['b2'] -= learning_rate * grads[4]
        self.weight['b3'] -= learning_rate * grads[5]





if __name__ == "__main__":
    from Datasets.DataReader import DataReader
    from Tools.CalcLoss import CrossEntropy
    model = FourLayerNeuralNetwork(784,256,10,0.1)
    reader= DataReader('../Datasets/MNIST',6)
    loss_fn = CrossEntropy(model)
    data,label = reader.get_batch(3)
    pred = model.forward(data)
    loss = loss_fn.forward(pred,label)
    grads = model.backpropagation(label,data)
    model.update(grads,0.1)
    print(pred.shape)
    print(grads)
    print(loss)
