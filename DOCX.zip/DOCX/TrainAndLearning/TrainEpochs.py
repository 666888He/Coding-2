import numpy as np
from tqdm import tqdm
import random
from Model import FourLayerNeuralNetwork
from Datasets.DataReader import DataReader
from Tools.CalcLoss import CrossEntropy
from Evalution import Evaluter

def initseed(seed):
    random.seed(seed)
    np.random.seed(seed)

class Trainer:
    def __init__(self,data_path,batch_size,
                 ch_in,ch_hid,num_cls,reg_lambda,learning_rate,):

        self.model = FourLayerNeuralNetwork(ch_in,ch_hid,num_cls,reg_lambda)

        self.lr = learning_rate

        self.dataloader = DataReader(data_path,batch_size)

        self.loss_fn = CrossEntropy(self.model)


    def __call__(self,epochs):

        for epoch in range(epochs):
            par = tqdm(range(self.dataloader.sample_num), total=self.dataloader.sample_num)
            self.dataloader.shuffle()
            loss_mean = 0
            if epoch in [int(epochs/3),int(2*epochs/3)]:
                self.lr *= 1-epoch/epochs

            for batch_id in par:
                sample,target = self.dataloader.get_batch(batch_id)
                pred = self.model.forward(sample)

                loss = self.loss_fn.forward(pred,target)

                grads = self.model.backpropagation(target,sample)

                self.model.update(grads,self.lr)

                correct_num = len(target[pred.argmax(axis=1)==target])

                loss_mean = (loss_mean*batch_id+loss)/(batch_id+1)
                par.set_description('Cur {}/{}, Loss: {:5f}, Learning Rate:{}, Correct Num: {}'.format(epoch,epochs,loss_mean,self.lr,correct_num))



if __name__ == "__main__":
    initseed(0)
    trainer = Trainer('../Datasets/MNIST',100,784,1024,10,0.0001,0.001)
    trainer(50)
    evaluater = Evaluter('../Datasets/MNIST',100,784,1024,10,trainer.model)
    evaluater()