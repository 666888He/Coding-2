import numpy as np


class CrossEntropy(object):
    def __init__(self,model):
        self.reg_lambda = model.reg_lambda
        self.model = model

    def forward(self,pred,y):
        batch_size = pred.shape[0]

        # Calculating the loss
        corect_logprobs = -np.log(pred[range(batch_size), y])
        loss = np.sum(corect_logprobs)

        # Add regulatization term to loss (optional)
        # loss += self.reg_lambda / 2 * (np.mean(np.square(self.model.weight['w1'])) + np.mean(np.square(self.model.weight['w2'])) + np.mean(np.square(self.model.weight['w3'])))
        # loss += self.reg_lambda / 2 * (np.mean(np.abs(self.model.weight['w1'])) + np.mean(np.abs(self.model.weight['w2'])) + np.mean(np.abs(self.model.weight['w3'])))

        return 1. / batch_size * loss