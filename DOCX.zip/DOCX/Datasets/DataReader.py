import random

import numpy as np
import os

class DataReader:
    def __init__(self,data_path,batch_size):
        dataImg = np.fromfile(open(os.path.join(data_path, 'train-images.idx3-ubyte')),dtype=np.uint8)
        dataLabel = np.fromfile(open(os.path.join(data_path, 'train-labels.idx1-ubyte')),dtype=np.uint8)
        # delete some invalid data
        self.dataLabel = dataLabel[8:].astype(np.int32)
        self.dataImg = dataImg[16:].reshape(60000,784).astype(np.float32)

        self.train_img = self.dataImg[:1000]
        self.train_label = self.dataLabel[:1000]

        self.test_img = self.dataImg[1000:1100]
        self.test_label = self.dataLabel[1000:1100]

        self.batch_size = batch_size

        self.sample_num = int(len(self.train_img)/batch_size)
        self.indexes = [i for i in range(self.sample_num)]

        self.test_num = int(len(self.test_img) / batch_size)
        self.test_indexes = [i for i in range(self.test_num)]



    def get_batch(self,id):
        idx = self.indexes[id]
        # return self.dataImg[idx*self.batch_size:(idx+1)*self.batch_size,:],self.dataLabel[idx*self.batch_size:(idx+1)*self.batch_size]
        return self.train_img[idx*self.batch_size:(idx+1)*self.batch_size,:],self.train_label[idx*self.batch_size:(idx+1)*self.batch_size]

    def get_test_batch(self,id):
        idx = self.indexes[id]
        return self.test_img[idx*self.batch_size:(idx+1)*self.batch_size,:],self.test_label[idx*self.batch_size:(idx+1)*self.batch_size]

    def shuffle(self):
        random.shuffle(self.indexes)


if __name__ == "__main__":
    reader = DataReader('F:/Epiboly/BackPropagation/Datasets/MNIST',20)
    print(reader.get_batch(3))
